package br.com.app.bus.model;

public enum BusType {
    PUBLIC, PRIVATE
}
