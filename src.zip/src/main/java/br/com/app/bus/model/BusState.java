package br.com.app.bus.model;

public enum BusState {
    ACTIVE, INACTIVE
}
