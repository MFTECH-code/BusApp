package br.com.app.bus.model.dto.bus;

public record UpdateBusDTO(
        Double rate

) {
}
